<?php
defined('_JEXEC') or die;

require_once JPATH_PLUGINS . "/editors-xtd/websitetemplate/vendor/autoload.php";

class PlgButtonWebsitetemplate extends JPlugin
{
   
    protected $autoloadLanguage = false;

    public function onDisplay($name)
    {
        $loader = new Twig_Loader_Filesystem(__DIR__);
        $twig = new Twig_Environment($loader);

        $button          = new JObject;
        $button->modal   = true;
        $button->class   = 'btn';
        $button->onclick = $twig->render('main.js');
        $button->text    = JText::_('網站模版');
        $button->name    = 'arrow-down';
        $button->link    = 'index.php?option=com_websitetemplate&task=websitetemplate.plugin';
        $button->options = "{handler: 'iframe', size: {x: 1600, y: 800}}";

        return $button;
    }
}
