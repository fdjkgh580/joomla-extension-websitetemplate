<?php
defined('_JEXEC') or die;

echo JPATH_COMPONENT_ADMINISTRATOR . '/vendor/autoload.php';

class WebsitetemplateController extends JControllerLegacy
{
    public function __construct($config = array())
    {
        parent::__construct($config);
    }

    public function display($cachable = false, $urlparams = array())
    {
        $this->setRedirect(JRoute::_('index.php?option=com_websitetemplate&task=websitetemplate.index', false));
    }
}