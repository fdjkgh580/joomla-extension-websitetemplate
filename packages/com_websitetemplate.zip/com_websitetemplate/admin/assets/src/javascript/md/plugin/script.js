$(function (){
    $.vmodel.create({
        selector: '.script',
        model: '--script',
        isautoload: false,
        method: function (){
            var vs = this;
            this.autoload = ['init'];
            this.init = function (){
                
            }

            var _target = function (usethis){
                return $(usethis).parents("td").find(".script")
            }

            this.findHtml = function (selector){
                return $(selector).find(".script").find(".html").val();
            }

            this.getHtml = function (usethis){
                return _target(usethis).find(".html").val();
            }

            this.getCss = function (usethis){
                return _target(usethis).find(".css").val();
            }
            
        }
    });
    
})