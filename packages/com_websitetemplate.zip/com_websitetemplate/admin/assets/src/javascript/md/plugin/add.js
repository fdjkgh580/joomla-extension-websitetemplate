$(function (){
    $.vmodel.create({
        selector: '.btnsite',
        model: '--add',
        isautoload: false,
        method: function (){
            var vs = this;
            this.autoload = ['init', 'click'];
            this.init = function (){
                $("#sbox-window", parent.document).css("padding", 0);
            }

            this.click = function (){
                vs.root.on("click", ".add", function (){

                    // 取得編碼
                    var cssScript = $.vmodel.get("script").getCss(this);
                    var css = "<style>" + cssScript + "</style>";
                    var html = $.vmodel.get("script").getHtml(this);

                    var code = css + html;

                    // 寫入
                    window.parent.jInsertEditorText(code, 'jform_articletext');
                    window.parent.jModalClose();
                });
            }

            this.findShow = function (usethis){
                vs.hideAll();
                $(usethis).find(".add").removeClass('hide');
            }

            this.hideAll = function (){
                vs.root.find(".add").addClass('hide');
            }
        }
    });
    
})