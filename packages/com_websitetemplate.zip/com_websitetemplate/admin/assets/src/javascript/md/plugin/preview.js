$(function (){
    $.vmodel.create({
        selector: '.preview',
        model: '--preview',
        isautoload: false,
        method: function (){
            var vs = this;
            this.autoload = ['init'];
            this.init = function (){
                
            }

            var _codesite = function (){
                return vs.root.find(".codesite");
            }

            this.set = function (html){
                
                // 縮小後放大顯示
                vs.root.find(".codesite").transit({
                    scale  : '0.9',
                    opacity: 0
                }, 100, function (){
                    vs.root.find(".codesite").html(html);
                    vs.root.find(".codesite").css({
                        scale  : '1',
                        opacity: 1
                    }, 50)
                })
            }
        }
    });
    
})