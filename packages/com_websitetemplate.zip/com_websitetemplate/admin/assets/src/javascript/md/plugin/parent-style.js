$(function (){
    $.vmodel.create({
        selector: parent.document,
        model: '--parentStyle',
        isautoload: false,
        method: function (){
            var vs = this;
            this.autoload = ['init', 'coverPopFrame'];
            this.init = function (){
                
            }

            this.parent = function (selector){
                return $(selector, vs.selector);
            }

            // 修改外框顯示
            this.coverPopFrame = function (){
                var curr = $.vmodel.get("editor").currEditor();
                if (curr == "tinyMCE"){
                    var defStyle = vs.parent("#mceu_101").attr("style");
                    var newStyle = defStyle + "padding: 0px !important;";

                    vs.parent("#mceu_101").attr("style", newStyle)
                    vs.parent("#mceu_101-head").remove();
                }
                else if (curr == "JCE"){
                    vs.parent("#sbox-window").css("padding", 0);
                }
            }
        }
    });
    
})