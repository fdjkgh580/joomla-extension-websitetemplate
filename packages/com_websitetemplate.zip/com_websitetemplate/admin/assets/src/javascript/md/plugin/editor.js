$(function (){
    $.vmodel.create({
        selector: '.editor-block',
        model: '--editor',
        isautoload: false,
        method: function (){
            var vs = this;
            this.autoload = ['init'];
            this.init = function (){
                var curr = vs.currEditor();
                if (curr == "JCE"){
                    _removeJCETool();
                }
            }

            // 監聽 JCE 渲染完畢，移除不需要的按鈕
            var _removeJCETool = function (){
                var id = setInterval(function (){

                    // 移除 preview
                    var target = vs.root.find("a[href='#wf-editor-preview']");
                    if (target.length == 0) return false;

                    vs.root.find("a[href='#wf-editor-preview']").remove();
                    
                    // 移除 toolbar
                    vs.root.find(".mceToolbar").remove();

                    clearInterval(id);

                }, 0)
            }

            // 取得編輯器的 HTML
            this.getHtml = function (){
                var content = false;
                var current = vs.currEditor();

                if (current === "tinyMCE") {
                    var content = tinyMCE.activeEditor.getContent();
                }
                else if (current === "JCE") {
                    var content = vs.root.find("#jform_editor_ifr").contents().find("body").html();
                }
                else if (current === false) {
                    console.log('找不到編輯器');
                }

                return content;
            }

            // 替換編輯器的 HTML
            this.setHtml = function (htmlCode){

                var current = vs.currEditor();

                if (current == "tinyMCE") {
                    var content = tinyMCE.activeEditor.setContent(htmlCode);
                }
                else if (current === "JCE") {
                    vs.root.find("#jform_editor_ifr").contents().find("body").html(htmlCode);
                }
                else if (current === false) {
                    console.log('找不到編輯器');
                }
            }

            // 取得當前的編輯器
            this.currEditor = function (){
                var num = $(".js-editor-tinymce").length;
                if (num > 0) {
                    return 'tinyMCE';
                }

                var num = $(".wf-editor-container").length;
                if (num > 0) {
                    return 'JCE';
                }

                return false;
            }

        }
    });
    
})