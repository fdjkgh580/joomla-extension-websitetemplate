$(function (){
    $.vmodel.create({
        selector: '.formlist',
        model: '--table',
        isautoload: false,
        method: function (){
            var vs = this;
            this.autoload = ['init', 'hover', 'click'];
            this.init = function (){

            }

            var _removeChoice = function (){
                vs.root.find(".choice").removeClass('choice');
            }

            // 若該項目有選取
            var _isExistChoice = function (trthis){
                return $(trthis).hasClass('choice');
            }

            // 若沒有選取任何項目
            var _isNotExistAnyChoice = function (){
                return vs.root.find("table tbody tr.choice").length == 0 ? true : false; 
            }

            // 標記自己並觸發
            var _clickSelfAndShow = function (usethis){
                $(usethis).addClass("choice");
                // $.vmodel.get("add").findShow(usethis); 
            }

            this.click = function (){
                vs.root.find("table tbody").on("click", "tr", function (){


                    // 若沒有選取任何項目
                    if (_isNotExistAnyChoice()){
                        _clickSelfAndShow(this);
                    }

                    // 若該項目有選取，則取消鎖定
                    else if (_isExistChoice(this)){
                        _removeChoice();
                        $.vmodel.get("add").hideAll();
                    }
                    
                    // 已經點選過其他項目
                    else {

                        // 移除已經點選的標記
                        _removeChoice();

                        // 標記自己並觸發
                        _clickSelfAndShow(this);

                        var html = $.vmodel.get("script").findHtml(this);
                        $.vmodel.get("preview").set(html);
                    }
                });
            }

            var _isLock = function (){
                return vs.root.find("table tbody tr.choice").length > 0 ? true : false;
            }
            
            this.hover = function (){
                vs.root.find("table tbody tr").hover(function (){
                    
                    // 顯示按鈕
                    $.vmodel.get("add").findShow(this);
                    
                    // 若點選就不必預覽
                    if (_isLock()) return false;

                    // 預覽
                    var html = $.vmodel.get("script").findHtml(this);
                    $.vmodel.get("preview").set(html);
                    
                }, function (){

                    $.vmodel.get("add").hideAll(this);
                })

            }
        }
    });
    
})