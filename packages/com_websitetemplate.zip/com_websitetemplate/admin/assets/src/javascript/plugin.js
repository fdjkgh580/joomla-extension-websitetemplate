// 載入 SCSS
import '../scss/global.scss';
import '../scss/plugin.scss';

// 載入 jQuery Plugin
import '../../../node_modules/vmodel.js/dist/jquery.vmodel.min.js';
import '../../../node_modules/jquery.transit/jquery.transit.js';

// 載入會使用到的 JS 程式碼
import './md/plugin/table.js';
import './md/plugin/add.js';
import './md/plugin/script.js';
import './md/plugin/preview.js';
import './md/plugin/editor.js';
import './md/plugin/parent-style.js';

$(function (){
    $.vmodel.get("table", true);
    $.vmodel.get("add", true);
    $.vmodel.get("script", true);
    $.vmodel.get("preview", true);
    $.vmodel.get("editor", true);
    $.vmodel.get("parentStyle", true);
})