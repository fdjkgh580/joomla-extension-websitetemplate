<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/vendor/autoload.php';

new \Jsnlib\Joomla\EasyRequest;

class WebsitetemplateControllerWebsitetemplate extends JControllerLegacy
{
    use \Jsnlib\Joomla\EasyRequestTrait;

    function __construct($config = array())
    {
        parent::__construct($config);
        $this->wtModel = $this->getModel('Websitetemplate');

        // 解決 Joomla 問題：Notice: Indirect modification of overloaded property
        function _cleanText($text)
        {
            if (!isset($text)) 
            {
                return $text;
            } 
            return JFilterOutput::cleanText($text);
        }
    }

    public function display($cachable = false, $urlparams = array())
    {
        parent::display($cachable, $urlparams);
    }

    public function index()
    {
        $view = $this->getView('Websitetemplate', 'html');
        $view->datalist = $this->wtModel->getAll();

        if (count($view->datalist) == 0) 
        {
            $this->setRedirect(JRoute::_(
            [
                'option' => 'com_websitetemplate', 
                'task' => 'websitetemplate.insert'
            ], false), '新增您的第一筆模版', 'message');

            return true;
        }

        $view->setLayout('main');
        $view->index();
    }

    // 外掛使用
    public function plugin()
    {
        $this->input->set('tmpl', 'component');

        $view = $this->getView('Websitetemplate', 'html');
        $view->datalist = $this->wtModel->getAll();
        $view->setLayout('plugin');
        $view->plugin();
    }

    public function insert()
    {
        $view = $this->getView('Websitetemplate', 'html');
        $view->editModel = $this->getModel('Edit');
        $view->setLayout('edit');

        $view->wt_id      = null;
        $view->wt_title   = null;
        $view->wt_css     = null;
        $view->wt_content = null;

        $view->insert();
    }

    public function update()
    {
        $view = $this->getView('websitetemplate', 'html');
        $view->editModel = $this->getModel('Edit');
        $view->setLayout('edit');

        $wtinfo = $this->wtModel->getOne(new \Jsnlib\Ao(
        [
            'wt_id' => $this->getInt('wt_id')            
        ]));

        if (count($wtinfo) == 0) throw new \Exception('Error');

        $clean = function($ary)
        {
            return $ary;
        };

        $view->wt_id      = $this->getInt('wt_id');
        $view->wt_title   = _cleanText($wtinfo->wt_title);
        $view->wt_content = $wtinfo->wt_content; // 應該保留 HTML 但不需要 JS
        $view->wt_css     = _cleanText($wtinfo->wt_css);
        
        $view->update();
    }

    public function query_insert()
    {
        JSession::checkToken() or die( 'Invalid Token' );

        $jform = new \Jsnlib\Ao($this->post('jform', null, 'array'));

        $this->wtModel->insert(new \Jsnlib\Ao(
        [
            'title' => $jform->title,
            'content' => $jform->content,
            'css' => $jform->css
        ]));

        $this->setRedirect(JRoute::_(
        [
            'option' => 'com_websitetemplate', 
            'task' => 'websitetemplate.index'
        ], false), '新增成功', 'message');
    }

    public function query_update()
    {
        JSession::checkToken() or die( 'Invalid Token' );

        $jform = new \Jsnlib\Ao($this->post('jform', null, 'array'));

        $this->wtModel->update(new \Jsnlib\Ao(
        [
            'id' => $this->post('wt_id'),
            'title' => $jform->title,
            'content' => $jform->content,
            'css' => $jform->css
        ]));

        $this->setRedirect(JRoute::_(
        [
            'option' => 'com_websitetemplate', 
            'task' => 'websitetemplate.index'
        ], false), '修改成功', 'message');
    }

    public function query_delete()
    {
        JSession::checkToken() or die( 'Invalid Token' );

        $this->wtModel->delete(new \Jsnlib\Ao(
        [
            'wt_id' => $this->post('cid')
        ]));

        $this->setRedirect(JRoute::_(
        [
            'option' => 'com_websitetemplate', 
            'task' => 'websitetemplate.index'
        ], false), '刪除成功', 'message');
    }
}