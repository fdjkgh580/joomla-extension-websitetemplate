<?php
defined('_JEXEC') or die;

class WebsitetemplateViewWebsitetemplate extends JViewLegacy
{
    public function __construct($config = array())
    {
        parent::__construct($config);   
    }

    public function display($tpl = null)
    {
        parent::display($tpl);
    }

    public function index()
    {
        JToolbarHelper::title('Website Template：管理');
        JToolbarHelper::link(JRoute::_(['option'=>'com_websitetemplate', 'task'=>'websitetemplate.insert']), '新增', 'new');
        JToolBarHelper::deleteList( '確定要刪除嗎', 'websitetemplate.query_delete');
        parent::display();
    }

    public function plugin()
    {
        parent::display();
    }

    public function insert()
    {
        $this->form = $this->editModel->getForm();

        JToolbarHelper::title('Website Template：新增');
        JToolbarHelper::save('websitetemplate.query_insert');
        JToolbarHelper::cancel();

        parent::display();
    }

    public function update()
    {
        $this->form = $this->editModel->getForm();

        JToolbarHelper::title('Website Template：修改');
        JToolbarHelper::save('websitetemplate.query_update');
        JToolbarHelper::cancel();

        parent::display();
    }
    
    
    
}