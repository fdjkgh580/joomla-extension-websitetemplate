<form action="<?php echo JUri::getInstance(); ?>" id="adminForm" name="adminForm" method="post">

    <?=$this->form->renderField('title', null, $this->wt_title);?>

    <!-- <?=$this->form->renderField('css', null, $this->wt_css);?> -->

    <?=$this->form->renderField('content', null, $this->wt_content);?>
    
    <?=JHtml::_('form.token'); ?>
    <div class="hidden-inputs">
        <input type="hidden" name="option" value="com_websitetemplate">
        <input type="hidden" name="task" value="">
        <?php if (!empty($this->wt_id)) { ?>
            <input type="hidden" name="wt_id" value="<?=$this->wt_id?>">
        <? } ?>
    </div>
</form>