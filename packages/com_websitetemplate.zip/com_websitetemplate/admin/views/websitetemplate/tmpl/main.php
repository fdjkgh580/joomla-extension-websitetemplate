<form action="<?=JUri::getInstance(); ?>" id="adminForm" name="adminForm" method="post">
    <p>
        您可以在編輯器中找到「網站模版」按鈕，插入您的模版。
    </p>
    <table class="table table-inverse col-5">
        <thead>
            <tr>
                <th style="width: 50px">
                    <?=JHtml::_('grid.checkall'); ?>
                </th>
                <th>名稱</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($this->datalist as $key => $datainfo) { ?>
                <tr>
                    <td>
                        <?=JHtmlGrid::id($key, $datainfo->wt_id)?>
                    </td>
                    <td>
                        <?php $temp = $datainfo->wt_title?>
                        <a href="<?=JRoute::_(['option' => 'com_websitetemplate', 'task' => 'websitetemplate.update', 'wt_id' => $datainfo->wt_id ])?>">
                            <?=JFilterOutput::cleanText($temp)?>
                        </a>
                    </td>
                </tr>
            <? } ?>
        </tbody>
    </table>

    <?=JHtml::_('form.token'); ?>
    <div class="hidden-inputs">
        <input type="hidden" name="option" value="com_websitetemplate">
        <input type="hidden" name="task" value="">
        <input name="boxchecked" type="hidden" value="0">

        <input name="filter_order" type="hidden" value="">
        <input name="filter_order_Dir" type="hidden" value="">
    </div>
</form>
