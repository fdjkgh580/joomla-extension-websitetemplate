<form action="<?php echo JUri::getInstance(); ?>" id="adminForm" name="adminForm" method="post">
    <p>
        您可以在編輯器中找到「網站模版」按鈕，插入您的模版。
        <a href="https://github.com/fdjkgh580/joomla-extension-websitetemplate" target="+blank">安裝資訊可參考我。</a>
    </p>
    <table class="table table-inverse col-5">
        <thead>
            <tr>
                <th style="width: 50px">
                    <?php echo JHtml::_('grid.checkall'); ?>
                </th>
                <th>名稱</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($this->datalist as $key => $datainfo): ?>
                <tr>
                    <td>
                        <?php echo JHtmlGrid::id($key, $datainfo->wt_id)?>
                    </td>
                    <td>
                        <?php $temp = $datainfo->wt_title?>
                        <a href="<?php echo JRoute::_(['option' => 'com_websitetemplate', 'task' => 'websitetemplate.update', 'wt_id' => $datainfo->wt_id ])?>">
                            <?php echo JFilterOutput::cleanText($temp)?>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php echo JHtml::_('form.token'); ?>
    <div class="hidden-inputs">
        <input type="hidden" name="option" value="com_websitetemplate">
        <input type="hidden" name="task" value="">
        <input name="boxchecked" type="hidden" value="0">

        <input name="filter_order" type="hidden" value="">
        <input name="filter_order_Dir" type="hidden" value="">
    </div>
</form>
