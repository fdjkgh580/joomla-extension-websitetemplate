<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
    <base href="<?php echo JURI::root(); ?>">
    <script src="administrator/components/com_websitetemplate/assets/dist/vendors.js?t=<?php echo uniqid()?>"></script>
    <script src="administrator/components/com_websitetemplate/assets/dist/plugin.js?t=<?php echo uniqid()?>"></script>

    <div class="com_container">

        <?php if (count($this->datalist) == 0) { ?>
            <p style="text-align: center; width: 600px; margin: 0 auto; padding-top: 3rem; font-size: 16px">
                請先前往 「元件 > Website Template 網站模版」 建立一項您的模版。
            </p>
        <?php } else { ?>
            <div class="preview">
                <div class="codesite"></div>
            </div>

            <form class="formlist" action="<?php echo JUri::getInstance(); ?>" id="adminForm" name="adminForm" method="post">
                <table>
                    <tbody>
                        <?php foreach ($this->datalist as $key => $datainfo) { ?>
                            <tr title="點選可鎖定預覽">
                                <td>
                                    <?php $temp = $datainfo->wt_title?>
                                    <a
                                        target="_blank"
                                        href="<?php echo JRoute::_(['option' => 'com_websitetemplate', 'task' => 'websitetemplate.update', 'wt_id' => $datainfo->wt_id])?>">
                                        <?php echo JFilterOutput::cleanText($temp)?>
                                    </a>
                                </td>
                                <td style="width: 150px">
                                    <span class="script" hidden>
                                        <textarea class="css"><?php echo $datainfo->wt_css?></textarea>
                                        <textarea class="html"><?php echo $datainfo->wt_content?></textarea>
                                    </span>

                                    <span class="btnsite">
                                        <button type="button" class="btn btn-lg btn-primary add hide font">使用</button>
                                    </span>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </form>
        <?php } ?>
    </div>
</body>
</html>