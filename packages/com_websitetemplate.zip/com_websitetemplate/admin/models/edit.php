<?php
defined('_JEXEC') or die;

class WebsitetemplateModelEdit extends JModelAdmin
{
    public function __construct($config = array())
    {
        parent::__construct($config);   
    }
    
    public function getForm($data = Array(), $loadData = true)
    {
        $form = $this->loadForm
        (
            'com_websitetemplate.edit',
            'edit', 
            array('control' => 'jform', 'load_data' => $loadData)
        );
 
        return $form;
    }
}