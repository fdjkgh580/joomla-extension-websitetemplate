<?php 
require_once JPATH_COMPONENT_ADMINISTRATOR . '/vendor/autoload.php';
use Illuminate\Database\Capsule\Manager as DB;

trait Tool {
    
    protected $dbprefix;

    public function dbConnect()
    {

        $config = JFactory::getConfig();

        $db = new DB;
         
        $db->addConnection([
            'driver'    => 'mysql',
            'host'      => $config->get('host'),
            'database'  => $config->get('db'),
            'username'  => $config->get('user'),
            'password'  => $config->get('password'),
            'charset'   => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix'    => $config->get('dbprefix'),
        ]);
         
        $db->setAsGlobal();
        $db->bootEloquent();

        return 'Illuminate\Database\Capsule\Manager';
    }
}