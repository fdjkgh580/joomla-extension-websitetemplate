<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/vendor/autoload.php';
require_once 'tool.php';

use \Jsnlib\Joomla\Database\Eloquent\Helper as _Helper;

class WebsitetemplateModelWebsitetemplate extends JModelLegacy
{
    use Tool;

    public function __construct($config = array())
    {
        parent::__construct($config);  

        class_alias($this->dbConnect(), 'DB');
    }

    public function getAll($param = false)
    {
        $result = _Helper::proccess(false, function () use ($param) 
        {
            $builder = \DB::table("websitetemplate");
            $builder->select(['*']);
            $builder->orderBy("wt_id", "desc");
            return $builder->get();
        });

        return _Helper::selectResult($result, "list");
    }

    public function getOne($param = false)
    {
        $result = _Helper::proccess(false, function () use ($param) 
        {
            $builder = \DB::table("websitetemplate");
            $builder->select(['*']);
            $builder->where('wt_id', $param->wt_id);
            return $builder->get();
        });

        return _Helper::selectResult($result, "info");
    }
    
    public function save($param = false)
    {

    }

    public function insert($param = false)
    {

        $builder = \DB::table("websitetemplate");

        $builder->insert(
        [
            "wt_title" => $param->title,
            "wt_content" => $param->content,
            "wt_css" => $param->css,
        ]);
        
        return $lastInsertId = \DB::getPdo()->lastInsertId();
    }

    public function update($param = false)
    {
        $result = _Helper::proccess(false, function () use ($param) 
        {
            $builder = \DB::table("websitetemplate");
            $builder->where("wt_id", $param->id);
            $num = $builder->update(
            [
                "wt_title" => $param->title,
                "wt_content" => $param->content,
                "wt_css" => $param->css,
            ]);
            
            return $num;
        });
    }

    public function delete($param = false)
    {
        $result = _Helper::proccess(false, function () use ($param)
        {
            return $num = \DB::table("websitetemplate")
                ->whereIn("wt_id", $param->wt_id->toArray())
                ->delete();
        });
    }

}