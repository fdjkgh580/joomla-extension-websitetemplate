CREATE TABLE IF NOT EXISTS `#__websitetemplate` (
  `wt_id` int(10) NOT NULL AUTO_INCREMENT,
  `wt_title` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `wt_content` longtext COLLATE utf8_unicode_ci,
  `wt_css` longtext COLLATE utf8_unicode_ci,
  `wt_javascript` longtext COLLATE utf8_unicode_ci,
  `wt_created_at` datetime NOT NULL,
  `wt_updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`wt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;